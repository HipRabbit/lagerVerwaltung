package thw.edu.javaII.port.warehouse.model.deo;

public enum Zone {
    PRODUKT, LAGER, LAGERPLATZ, LAGERBESTAND, INIT, STATISTIK, GENERAL, DEMO, KUNDE, BESTELLUNG, NACHBESTELLUNG
}