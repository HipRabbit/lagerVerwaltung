package thw.edu.javaII.port.warehouse.model.deo;

public enum Status {
	OK, INFO, ERROR
}
