package thw.edu.javaII.port.warehouse.model.common;

public class Info {
	public final static String SAVE_FILE_NAME = "Lagverwaltung.dat";
	public final static int PORT_SERVER = 5010;
	public final static String NAME_SERVER = "localhost";
	public final static int TIMEOUT_CLIENT = 50000;
	public final static String LOG_NAME = "warehouse.log";
}
