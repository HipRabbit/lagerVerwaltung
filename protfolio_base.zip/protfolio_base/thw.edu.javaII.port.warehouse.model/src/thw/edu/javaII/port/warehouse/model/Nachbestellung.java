package thw.edu.javaII.port.warehouse.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Nachbestellung implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private Produkt produkt;
    private int anzahl;
    private Date datum;
    private String status;

    public Nachbestellung() {
        this.status = "offen";
    }

    public Nachbestellung(int id, Produkt produkt, int anzahl, Date datum) {
        this.id = id;
        this.produkt = produkt;
        this.anzahl = anzahl;
        this.datum = datum != null ? new Date(datum.getTime()) : new Date();
        this.status = "offen";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Produkt getProdukt() {
        return produkt;
    }

    public void setProdukt(Produkt produkt) {
        this.produkt = produkt;
    }

    public int getAnzahl() {
        return anzahl;
    }

    public void setAnzahl(int anzahl) {
        this.anzahl = anzahl;
    }

    public Date getDatum() {
        return datum != null ? new Date(datum.getTime()) : null;
    }

    public void setDatum(Date datum) {
        this.datum = datum != null ? new Date(datum.getTime()) : null;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}