/**
 * 
 */
/**
 * 
 */
module thw.edu.javaII.port.warehouse.model {
	exports thw.edu.javaII.port.warehouse.model;
	exports thw.edu.javaII.port.warehouse.model.deo;
	exports thw.edu.javaII.port.warehouse.model.common;
}