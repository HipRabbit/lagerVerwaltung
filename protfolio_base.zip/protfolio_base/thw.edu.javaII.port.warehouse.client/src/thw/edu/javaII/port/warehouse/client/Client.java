package thw.edu.javaII.port.warehouse.client;

public class Client {

	public static void main(String[] args) {
		Service service = new Service();
		service.work();
	}
}
