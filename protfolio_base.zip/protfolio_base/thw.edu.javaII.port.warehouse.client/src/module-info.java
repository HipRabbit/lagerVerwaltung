/**
 * 
 */
/**
 * 
 */
module thw.edu.javaII.port.warehouse.client {
	requires thw.edu.javaII.port.warehouse.model;
}