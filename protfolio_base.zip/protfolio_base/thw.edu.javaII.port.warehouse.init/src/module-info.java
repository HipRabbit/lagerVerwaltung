/**
 * 
 */
/**
 * 
 */
module thw.edu.javaII.port.warehouse.init {
	requires transitive thw.edu.javaII.port.warehouse.model;
	exports thw.edu.javaII.port.warehouse.init;
}