package thw.edu.javaII.port.warehouse.ui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import thw.edu.javaII.port.warehouse.model.deo.Command;
import thw.edu.javaII.port.warehouse.model.deo.WarehouseDEO;
import thw.edu.javaII.port.warehouse.model.deo.WarehouseReturnDEO;
import thw.edu.javaII.port.warehouse.model.deo.Zone;
import thw.edu.javaII.port.warehouse.ui.common.Session;
import thw.edu.javaII.port.warehouse.ui.panels.*;

public class LagerUIHandler implements ActionListener {
    private Session ses;
    private JFrame frame, parent;
    private JPanel contentPane;

    public LagerUIHandler(Session ses, JFrame frame, JPanel contentPane, JFrame parent) {
        super();
        this.ses = ses;
        this.frame = frame;
        this.contentPane = contentPane;
        this.parent = parent;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MenuActionCommands command = MenuActionCommands.valueOf(e.getActionCommand());
        BorderLayout layout = (BorderLayout) contentPane.getLayout();
        Component centerComponent = layout.getLayoutComponent(BorderLayout.CENTER);
        if (centerComponent != null) {
            contentPane.remove(centerComponent);
        }
        switch (command) {
            case BEENDEN:
                ses.close();
                frame.dispose();
                break;
            case STARTSEITE:
                contentPane.add(new WelcomePage(), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case SERVERBEENDEN:
                ses.getCommunicator().closeServer();
                frame.dispose();
                break;
            case DATENBANK:
                try {
                    WarehouseDEO deo = new WarehouseDEO();
                    deo.setZone(Zone.INIT);
                    deo.setCommand(Command.INIT);
                    WarehouseReturnDEO ret = ses.getCommunicator().sendRequest(deo);
                    if (ret.getStatus() == thw.edu.javaII.port.warehouse.model.deo.Status.OK) {
                        JOptionPane.showMessageDialog(parent, "Datenbank wurde initialisiert.", "Initialisierung", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(parent, "Fehler: " + ret.getMessage(), "Initialisierungsfehler", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(parent, "Fehler bei der Initialisierung: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
                }
                break;
            case BESTAND:
                contentPane.add(new BestandPage(ses), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case STATISTIK:
                contentPane.add(new StatistikPage(ses, parent), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case SUCHEN:
                contentPane.add(new SearchPage(ses, parent), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case INFO:
                contentPane.add(new InfoPage(), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case KUNDEN_DATENBANK:
                contentPane.add(new SearchKunde(ses, parent), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case BESTELLUNG_PAGE:
                contentPane.add(new BestellungPage(ses), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case LAGER:
                contentPane.add(new LagerPage(ses), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case LAGERPLATZ:
                contentPane.add(new LagerPlatzPage(ses), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case PRODUKT:
                contentPane.add(new ProduktPage(ses), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            case NACHBESTELLUNG_PAGE:
                contentPane.add(new NachbestellungPage(ses), BorderLayout.CENTER);
                frame.setVisible(true);
                break;
            default:
                break;
        }
        contentPane.revalidate();
        contentPane.repaint();
    }
}