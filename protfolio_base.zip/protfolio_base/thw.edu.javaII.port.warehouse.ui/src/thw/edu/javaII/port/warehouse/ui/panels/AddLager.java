package thw.edu.javaII.port.warehouse.ui.panels;

import java.awt.*;
import javax.swing.*;
import net.miginfocom.swing.MigLayout;
import thw.edu.javaII.port.warehouse.model.Lager;
import thw.edu.javaII.port.warehouse.model.deo.WarehouseDEO;
import thw.edu.javaII.port.warehouse.model.deo.WarehouseReturnDEO;
import thw.edu.javaII.port.warehouse.model.deo.Zone;
import thw.edu.javaII.port.warehouse.model.deo.Command;
import thw.edu.javaII.port.warehouse.ui.common.Session;

public class AddLager extends JDialog {
    private Session ses;
    private JTextField txtName, txtOrt, txtArt;
    private JButton btnSave, btnCancel;

    public AddLager(Session ses, JFrame parent) {
        super(parent, "Lager anlegen", true);
        this.ses = ses;
        initializeUI();
    }

    private void initializeUI() {
        setLayout(new MigLayout("fill, wrap 2", "[right][left, grow]", "[]10[]"));
        setSize(400, 200);
        setLocationRelativeTo(getParent());

        // Eingabefelder
        add(new JLabel("Name:"));
        txtName = new JTextField(20);
        add(txtName, "growx");

        add(new JLabel("Ort:"));
        txtOrt = new JTextField(20);
        add(txtOrt, "growx");

        add(new JLabel("Art:"));
        txtArt = new JTextField(20);
        add(txtArt, "growx");

        // Buttons in einem zentrierten Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnSave = new JButton("Speichern");
        btnSave.addActionListener(e -> saveLager());
        btnCancel = new JButton("Abbrechen");
        btnCancel.addActionListener(e -> dispose());
        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);
        add(buttonPanel, "span 2, center");
    }

    private void saveLager() {
        try {
            String name = txtName.getText().trim();
            String ort = txtOrt.getText().trim();
            String art = txtArt.getText().trim();

            if (name.isEmpty() || ort.isEmpty() || art.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Bitte füllen Sie alle Felder aus.", "Fehler", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Lager lager = new Lager(0, name, ort, art);
            WarehouseDEO deo = new WarehouseDEO();
            deo.setZone(Zone.LAGER);
            deo.setCommand(Command.ADD);
            deo.setData(lager);

            WarehouseReturnDEO ret = ses.getCommunicator().sendRequest(deo);
            if (ret.getStatus() == thw.edu.javaII.port.warehouse.model.deo.Status.OK) {
                JOptionPane.showMessageDialog(this, "Lager erfolgreich angelegt.", "Erfolg", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, ret.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Fehler: " + e.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }
}