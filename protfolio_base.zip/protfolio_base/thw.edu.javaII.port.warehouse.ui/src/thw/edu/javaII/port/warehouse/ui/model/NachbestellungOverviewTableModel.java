package thw.edu.javaII.port.warehouse.ui.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.table.AbstractTableModel;

import thw.edu.javaII.port.warehouse.model.Nachbestellung;

public class NachbestellungOverviewTableModel extends AbstractTableModel {
    private static final long serialVersionUID = 1L;
    private List<Nachbestellung> nachbestellungen;
    private final String[] columnNames = {"Nachbestellung-ID", "Produkt", "Anzahl", "Datum", "Status"};
    private final SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

    public NachbestellungOverviewTableModel(List<Nachbestellung> nachbestellungen) {
        this.nachbestellungen = nachbestellungen != null ? nachbestellungen : new ArrayList<>();
    }

    public void setData(List<Nachbestellung> nachbestellungen) {
        this.nachbestellungen = nachbestellungen != null ? nachbestellungen : new ArrayList<>();
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return nachbestellungen.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Nachbestellung nachbestellung = nachbestellungen.get(rowIndex);
        switch (columnIndex) {
            case 0: return nachbestellung.getId();
            case 1: return nachbestellung.getProdukt() != null ? nachbestellung.getProdukt().getName() : "Unbekannt";
            case 2: return nachbestellung.getAnzahl();
            case 3: return nachbestellung.getDatum() != null ? sdf.format(nachbestellung.getDatum()) : "Unbekannt";
            case 4: return nachbestellung.getStatus();
            default: return null;
        }
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0: return Integer.class;
            case 1: return String.class;
            case 2: return Integer.class;
            case 3: return String.class;
            case 4: return String.class;
            default: return Object.class;
        }
    }

    public Nachbestellung getNachbestellungAt(int rowIndex) {
        return nachbestellungen.get(rowIndex);
    }
}