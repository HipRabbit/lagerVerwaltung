package thw.edu.javaII.port.warehouse.ui.panels;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import thw.edu.javaII.port.warehouse.ui.common.Session;
import thw.edu.javaII.port.warehouse.ui.model.NachbestellungOverviewTableModel;
import thw.edu.javaII.port.warehouse.model.Nachbestellung;

public class NachbestellungPage extends JPanel {
    private static final long serialVersionUID = 1L;
    private Session session;
    private JTable table;
    private NachbestellungOverviewTableModel tableModel;

    public NachbestellungPage(Session session) {
        this.session = session;
        setLayout(new BorderLayout());
        initializeTable();
    }

    private void initializeTable() {
        List<Nachbestellung> nachbestellungen = session.getCommunicator().getNachbestellungen();
        tableModel = new NachbestellungOverviewTableModel(nachbestellungen);
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void refresh() {
        List<Nachbestellung> nachbestellungen = session.getCommunicator().getNachbestellungen();
        tableModel.setData(nachbestellungen);
    }
}