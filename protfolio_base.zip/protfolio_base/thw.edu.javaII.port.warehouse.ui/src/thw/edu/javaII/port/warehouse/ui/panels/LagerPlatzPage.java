package thw.edu.javaII.port.warehouse.ui.panels;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.IOException;
import thw.edu.javaII.port.warehouse.model.LagerPlatz;
import thw.edu.javaII.port.warehouse.model.deo.WarehouseDEO;
import thw.edu.javaII.port.warehouse.model.deo.WarehouseReturnDEO;
import thw.edu.javaII.port.warehouse.model.deo.Zone;
import thw.edu.javaII.port.warehouse.model.deo.Command;
import thw.edu.javaII.port.warehouse.ui.common.Session;
import thw.edu.javaII.port.warehouse.model.common.Cast;
import java.util.Comparator;
import java.util.Collections;

public class LagerPlatzPage extends JPanel {
    private Session ses;
    private JTable table;
    private LagerPlatzTableModel tableModel;

    public LagerPlatzPage(Session ses) {
        this.ses = ses;
        setLayout(new BorderLayout());
        initializeUI();
    }

    private void initializeUI() {
        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("Lagerplätze Übersicht");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        topPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel sortPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JToggleButton sortByIdButton = new JToggleButton("Sortieren nach ID");
        JToggleButton sortByNameButton = new JToggleButton("Sortieren nach Name");

        sortByIdButton.addActionListener(e -> {
            boolean ascending = !sortByIdButton.isSelected();
            tableModel.sortById(ascending);
            sortByIdButton.setText(ascending ? "Sortieren nach ID ↑" : "Sortieren nach ID ↓");
            sortByNameButton.setSelected(false);
            sortByNameButton.setText("Sortieren nach Name");
            updateSortIndicator(0, ascending); // Spalte 0 (ID)
        });

        sortByNameButton.addActionListener(e -> {
            boolean ascending = !sortByNameButton.isSelected();
            tableModel.sortByName(ascending);
            sortByNameButton.setText(ascending ? "Sortieren nach Name ↑" : "Sortieren nach Name ↓");
            sortByIdButton.setSelected(false);
            sortByIdButton.setText("Sortieren nach ID");
            updateSortIndicator(1, ascending); // Spalte 1 (Name)
        });

        sortPanel.add(sortByIdButton);
        sortPanel.add(sortByNameButton);
        topPanel.add(sortPanel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        JButton addButton = new JButton("Lagerplatz anlegen");
        JButton editButton = new JButton("Lagerplatz bearbeiten");
        JButton deleteButton = new JButton("Lagerplatz löschen");

        addButton.addActionListener(e -> {
            new AddLagerPlatz(ses, null).setVisible(true);
            refresh();
        });
        editButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                LagerPlatz selectedLagerPlatz = tableModel.getLagerPlatzAt(selectedRow);
                new EditLagerPlatz(ses, null, selectedLagerPlatz).setVisible(true);
                refresh();
            } else {
                JOptionPane.showMessageDialog(this, "Bitte wählen Sie einen Lagerplatz aus.", "Fehler", JOptionPane.ERROR_MESSAGE);
            }
        });
        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                LagerPlatz selectedLagerPlatz = tableModel.getLagerPlatzAt(selectedRow);
                new DeleteLagerPlatz(ses, null, selectedLagerPlatz).setVisible(true);
                refresh();
            } else {
                JOptionPane.showMessageDialog(this, "Bitte wählen Sie einen Lagerplatz aus.", "Fehler", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        tableModel = new LagerPlatzTableModel();
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        table.setRowHeight(25);
        table.getTableHeader().setDefaultRenderer(new SortIndicatorHeaderRenderer(table.getTableHeader().getDefaultRenderer()));
        add(new JScrollPane(table), BorderLayout.CENTER);

        refresh();
    }

    public void refresh() {
        try {
            WarehouseDEO deo = new WarehouseDEO();
            deo.setZone(Zone.LAGERPLATZ);
            deo.setCommand(Command.LIST);
            WarehouseReturnDEO ret = ses.getCommunicator().sendRequest(deo);
            if (ret.getStatus() == thw.edu.javaII.port.warehouse.model.deo.Status.OK) {
                java.util.List<LagerPlatz> lagerPlatzList = Cast.safeListCast(ret.getData(), LagerPlatz.class);
                tableModel.setData(lagerPlatzList);
            } else {
                JOptionPane.showMessageDialog(this, "Fehler beim Abrufen der Lagerplätze: " + ret.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
                tableModel.setData(new java.util.ArrayList<>());
            }
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Kommunikationsfehler: " + e.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
            tableModel.setData(new java.util.ArrayList<>());
        }
    }

    private void updateSortIndicator(int columnIndex, boolean ascending) {
        SortIndicatorHeaderRenderer renderer = (SortIndicatorHeaderRenderer) table.getTableHeader().getDefaultRenderer();
        renderer.setSortColumn(columnIndex, ascending);
        table.getTableHeader().repaint();
    }
}

class LagerPlatzTableModel extends javax.swing.table.AbstractTableModel {
    private java.util.List<LagerPlatz> data = new java.util.ArrayList<>();
    private String[] columnNames = {"ID", "Name", "Kapazität", "Lager"};

    public void setData(java.util.List<LagerPlatz> data) {
        this.data = data != null ? data : new java.util.ArrayList<>();
        fireTableDataChanged();
    }

    public LagerPlatz getLagerPlatzAt(int row) {
        return data.get(row);
    }

    public void sortById(boolean ascending) {
        Comparator<LagerPlatz> comparator = Comparator.comparingInt(LagerPlatz::getId);
        if (!ascending) comparator = comparator.reversed();
        Collections.sort(data, comparator);
        fireTableDataChanged();
    }

    public void sortByName(boolean ascending) {
        Comparator<LagerPlatz> comparator = Comparator.comparing(LagerPlatz::getName);
        if (!ascending) comparator = comparator.reversed();
        Collections.sort(data, comparator);
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int col) {
        LagerPlatz lagerPlatz = data.get(row);
        switch (col) {
            case 0: return lagerPlatz.getId();
            case 1: return lagerPlatz.getName();
            case 2: return lagerPlatz.getKapazitaet();
            case 3: return lagerPlatz.getLager_id() != null ? lagerPlatz.getLager_id().getName() : "Unbekannt";
            default: return null;
        }
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }
}