package thw.edu.javaII.port.warehouse.ui;

import thw.edu.javaII.port.warehouse.ui.common.Session;

public class Obeflaeche {

	public static void main(String[] args) {
		Session ses = new Session();
		LoginScreen fenster = new LoginScreen(ses);
		fenster.setVisible(true);
		fenster.setResizable(false);
		Starter start = new Starter(ses);
		start.start();
	}

}
