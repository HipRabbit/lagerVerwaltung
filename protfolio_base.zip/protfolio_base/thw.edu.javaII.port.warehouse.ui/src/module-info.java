/**
 * 
 */
/**
 * 
 */
module thw.edu.javaII.port.warehouse.ui {
	requires java.desktop;
	requires thw.edu.javaII.port.warehouse.model;
	requires miglayout15.swing;
}