/**
 * 
 */
/**
 * 
 */
module thw.edu.javaII.port.warehouse.server {
	requires thw.edu.javaII.port.warehouse.model;
	requires thw.edu.javaII.port.warehouse.init;
	requires java.sql;
	requires java.logging;
}